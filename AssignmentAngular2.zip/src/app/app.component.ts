import { Component, OnInit } from '@angular/core';
import { Employee } from './emp';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Assignment2';
  empID:number;
  empName:string;
  empSalary:number;
  empDept:string;
  editEnabled:boolean=false;
  employees:Employee[]=[];
  sortID:boolean=true;
  sortName:boolean=true;
  sortSalary:boolean=true;
  sortDept:boolean=true;
  constructor(private httpClient: HttpClient){}
  ngOnInit(){
    this.httpClient.get<Employee>("./assets/data.json").subscribe((data:any) =>{this.employees=data;})
  }
  addEmployee():void{
    let flag=0;
    for(let i=0;i<this.employees.length;i++){
      if(this.employees[i].empID == this.empID){
        flag=1;
      }
    }
    if(flag==0 || this.editEnabled){
      if(this.empID == null || this.empName == null || this.empSalary == null || this.empDept == null){
        document.getElementById('displayError').innerHTML="All the fields are neccessary.";
      }
      else{
        if(this.editEnabled){
          this.deleteEmp(this.empID);
          this.editEnabled=false;
        }
        alert(this.empID + " " + this.empName + " " + this.empSalary + " " + this.empDept);
        this.employees.push(new Employee(this.empID,this.empName,this.empSalary,this.empDept));
        this.empID=null;
        this.empName="";
        this.empSalary=null;
        this.empDept="";
      }
    }
    else{
      document.getElementById('displayError').innerHTML="This User ID already Exists.";
    }
  }
  updateEmp(empID):void{
    for(let i=0;i<this.employees.length;i++){
      if(this.employees[i].empID == empID){
        this.empID=this.employees[i].empID;
        this.empName=this.employees[i].empName;
        this.empSalary=this.employees[i].empSalary;
        this.empDept=this.employees[i].empDept;
        break;
      }
    }
    this.editEnabled=true;
  }
  deleteEmp(empID):void{
    let i;
    for(i=0;i<this.employees.length;i++){
      if(this.employees[i].empID == empID){
        break;
      }
    }
    this.employees.splice(i,1);
  }

  sortData(data){
    if(data=='id'){
      if(this.sortID){
        this.employees.sort((a,b)=>a.empID-b.empID);
        this.sortID=false;
      }
      else{
        this.employees.sort((a,b)=>b.empID-a.empID);
        this.sortID=true;
      }
    }
    else if(data=='name'){
      if(this.sortName){
        this.employees.sort((a,b)=>a.empName.localeCompare(b.empName));
        this.sortName=false;
      }
      else{
        this.employees.sort((a,b)=>b.empName.localeCompare(a.empName));
        this.sortName=true;
      }
    }
    else if(data=='salary'){
      if(this.sortSalary){
        this.employees.sort((a,b)=>a.empSalary-b.empSalary);
        this.sortSalary=false;
      }
      else{
        this.employees.sort((a,b)=>b.empSalary-a.empSalary);
        this.sortSalary=true;
      }
    }
    else{
      if(this.sortDept){
        this.employees.sort((a,b)=>a.empDept.localeCompare(b.empDept));
        this.sortDept=false;
      }
      else{
        this.employees.sort((a,b)=>b.empDept.localeCompare(a.empDept));
        this.sortDept=true;
      }
    }
  }
}
