export class Employee{
    empID:number;
    empName:string;
    empSalary:number;
    empDept:string;
    constructor(empID,empName,empSalary,empDept){
        this.empID=empID;
        this.empName=empName;
        this.empSalary=empSalary;
        this.empDept=empDept;
    }
}