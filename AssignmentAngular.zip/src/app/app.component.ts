import { Component, OnInit } from '@angular/core';
import { Employee } from './emp';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Assignment2';
  empID:number;
  empName:string;
  empSalary:number;
  empDept:string;
  employees:Employee[]=[];
  constructor(private httpClient: HttpClient){}
  ngOnInit(){
    this.httpClient.get<Employee>("./assets/data.json").subscribe((data:any) =>{this.employees=data;})
  }
  addEmployee():void{
    let flag=0;
    for(let i=0;i<this.employees.length;i++){
      if(this.employees[i].empID == this.empID){
        flag=1;
      }
    }
    if(flag==0){
      if(this.empID == null || this.empName == null || this.empSalary == null || this.empDept == null){
        document.getElementById('displayError').innerHTML="All the fields are neccessary.";
      }
      else{
        alert(this.empID + " " + this.empName + " " + this.empSalary + " " + this.empDept);
        this.employees.push(new Employee(this.empID,this.empName,this.empSalary,this.empDept));
        this.empID=null;
        this.empName="";
        this.empSalary=null;
        this.empDept="";
      }
    }
    else{
      document.getElementById('displayError').innerHTML="This User ID already Exists.";
    }
  }
  updateEmp(empID):void{
    for(let i=0;i<this.employees.length;i++){
      if(this.employees[i].empID == empID){
        this.empID=this.employees[i].empID;
        this.empName=this.employees[i].empName;
        this.empSalary=this.employees[i].empSalary;
        this.empDept=this.employees[i].empDept;
        break;
      }
    }
    this.deleteEmp(empID);
  }
  deleteEmp(empID):void{
    let i;
    for(i=0;i<this.employees.length;i++){
      if(this.employees[i].empID == empID){
        break;
      }
    }
    this.employees.splice(i,1);
  }
}